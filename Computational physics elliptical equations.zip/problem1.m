

L = 1;
a = 0.2;
b = 0.3;
Q0 = 4000;
a0 = 100;
Tout = 20;
T0 = 50;
v = 10;

hs = 0.1 * 2.^-(1:8);
Ts = cell(numel(hs), 1);

for i = 1:numel(hs)
    h = hs(i);
    [T, zs] = Fdiff(h, L, a, b, Q0, a0, Tout, T0, v);
    plot(zs, T);
    hold on
    Ts{i} = T;
end
hold off
legend(strsplit(num2str(hs)))
title("Part 1a: Solution for different step sizes h")
xlabel("z")
ylabel("T")
saveas(gcf, "problem1a_solution.png")


p = log2((Ts{end-2} - Ts{end-1}(1:2:end))./ (Ts{end-1}(1:2:end) - Ts{end}(1:4:end)));

plot(zs(1:4:end), p)
ylim([0 3])
xlabel("z")
ylabel("Order of accuracy p")
title("Part 1a: Order of accuracy over z")
saveas(gcf, "problem1a_orderofacc.png")


vs = [1 10 30 100];
hs = [0.1*2^-4 0.1*2^-4 0.1*2^-6 0.1*2^-8];%0.1*2.^-(3:2:20);
for i = 1:numel(vs)
    v = vs(i);
    h = hs(i);
    [T, zs] = Fdiff(h, L, a, b, Q0, a0, Tout, T0, v);
    plot(zs, T);
    hold on
end
hold off
legend(strsplit(num2str(vs))+", " + strsplit(num2str(hs(1:numel(vs)))))
title("Part 1b: Solution for different velocities v with their corresponding step size h.")
xlabel("z")
ylabel("T")
saveas(gcf, "problem1b_solution.png")


function [T, zs] = Fdiff(h, L, a, b, Q0, a0, Tout, T0, v)
    n = L/h + 1;
    zs = linspace(0, L, n);

    Qs = arrayfun(@(z) Q(z, a, b, Q0), zs);

    aj = -1/h^2 - v/(2*h);
    bj = 2/h^2;
    cj = -1/h^2 + v/(2*h);

    alph = @(v) -(sqrt(v^2/4+a0^2)-v/2);

    rhs = Qs;
    rhs(2) = rhs(2) - aj*T0;
    %rhs(end-1) = rhs(end-1) - cj*Tout*2*h*alph(v)/(2*h*alph(v) +3);%cj * (alph(v)*Tout/(3/(2*h) + alph(v))); % TODO THIS IS THE ISSUE! How to approximate boundary condition second order?
    rhs(end) = rhs(end) - 2*h*alph(v)*cj*Tout;
    
    %A = sparse(diag(aj*ones(n-3,1),-1) + diag(bj*ones(n-2,1),0) + diag(cj*ones(n-3,1),+1));
    %A(end,end-1) = A(end,end-1) - cj /(2*h*alph(v) +3);%cj/(2*h)*(1/(3/(2*h) + alph(v)));
    %A(end,end) = A(end,end) + 4*cj/(2*h*alph(v) +3);%- cj/(2*h)*(-4/(3/(2*h) + alph(v)));
    A = sparse(diag(aj*ones(n-2,1),-1) + diag(bj*ones(n-1,1),0) + diag(cj*ones(n-2,1),+1));
    A(end,end-1) = A(end,end-1) + cj;
    A(end,end) = A(end,end) - 2*h*alph(v)*cj;
    
    
    T = ones(n, 1);
    T(1) = T0;
    
    %[c,R] = qr(A,rhs(2:end-1)');
    %T(2:end-1) = R\c;
    %T(end) = T(end-2)*1/(2*h)*(1/(3/(2*h) + alph(v))) + T(end-1)*1/(2*h)*(-4/(3/(2*h) + alph(v))) + (alph(v)*Tout/(3/(2*h) + alph(v)));
    [c,R] = qr(A,rhs(2:end)');
    T(2:end) = R\c;
    
end



function val = Q(z, a, b, Q0)
   if (z >= a) & (z <= b)
       val = Q0 * sin((z-a)*pi/(b-a));
   else
       val = 0;
   end
end

