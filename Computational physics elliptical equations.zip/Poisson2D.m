L = 5;
H = 2;
f = 100;
boundaryL = 40;
boundaryR = 400;


h = .1;

M = L/h + 1;
N = H/h + 1;
TOTAL = M*N;

% k = i*M + j

k = (j-1)*M + (i-1) + 1;

A = sparse(TOTAL, TOTAL);
b = zeros(TOTAL, 1);

for k = 1:TOTAL
    i = mod(k - 1, M) + 1;
    j = floor((k - 1)/M) + 1;
    
    if i == 1          % L boundary stuff
        A(k, k) = 1;
        b(k) = boundaryL;
    elseif i ==  M     % R boundry stuff
        A(k, k) = 1;
        b(k) = boundaryR;
    elseif j == 1      % B boundary stuff
        A(k, k)   = -1;
        A(k, k+M) = +1;
        
    elseif j == N      % T boundry stuff
        A(k, k)   = +1;
        A(k, k-M) = -1;
    else
        A(k, k)   = -4;
        A(k, k-1) =  1;
        A(k, k+1) =  1;
        A(k, k+M) =  1;
        A(k, k-M) =  1;
        
        b(k) = -f*h^2;
    end
    
end

T = A\b;

[ x, y ] = ndgrid(0:h:L, 0:h:H);
exact = -.5*f*x.^2 + (boundaryR - boundaryL + .5*f*L^2)/L*x + boundaryL;

T = reshape(T, M, N);
clf
mesh(x, y, T)
hold on
mesh(x, y, exact)
figure(gcf)

i = 3/h+1;
j = 1/h+1;

TValue = T(i, j);

% Part B

max(max(abs(T - exact)))
max(b - A*reshape(exact, M*N, 1))