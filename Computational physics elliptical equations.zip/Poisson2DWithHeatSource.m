function TValue = Poisson2DWithHeatSource(h)

L = 5;
H = 2;
heatsource = @(x, y) 6000*exp(-5*(x-1)^2 - 10*(y-1.5)^2);
boundaryL = 40;
boundaryR = 400;

%h = .1/2/2/2;

M = L/h + 1;
N = H/h + 1;
TOTAL = M*N;

% k = i*M + j

% k = (j-1)*M + (i-1) + 1;

A = sparse(TOTAL, TOTAL);
b = zeros(TOTAL, 1);

for k = 1:TOTAL
    i = mod(k - 1, M) + 1;
    j = floor((k - 1)/M) + 1;
    
    x = (i - 1)*h;
    y = (j - 1)*h;
    f = heatsource(x, y);
    
    if i == 1          % L boundary stuff
        A(k, k) = 1;
        b(k) = boundaryL;
    elseif i ==  M     % R boundry stuff
        A(k, k) = 1;
        b(k) = boundaryR;
    elseif j == 1      % B boundary stuff
        A(k, k)     = -3/2;
        A(k, k+M)   = +2;
        A(k, k+2*M) = -1/2;        
    elseif j == N      % T boundry stuff
        A(k, k)     = -3/2;
        A(k, k-M)   = +2;
        A(k, k-2*M) = -1/2;
    else
        A(k, k)   = -4;
        A(k, k-1) =  1;
        A(k, k+1) =  1;
        A(k, k+M) =  1;
        A(k, k-M) =  1;
        
        b(k) = -f*h^2;
    end
    
end

T = A\b;

[ x, y ] = ndgrid(0:h:L, 0:h:H);
T = reshape(T, M, N);
contour(x, y, T);
% clf
% image(0:h:H, 0:h:L, T)
hold on
surf(x, y, T);
xlabel('x')
ylabel('y')
zlabel('T')
figure(gcf)

i = 3/h+1;
j = 1/h+1;

TValue = T(i, j);
