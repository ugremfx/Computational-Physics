
%hs = [ 1 0.5 0.25 0.125 0.0625 0.0625/2 ];
%hs = [ 0.1 0.05 0.025];

hs = 0.05
%hs = 2.^-(0:4);

for run = 1:length(hs)
    disp(run)
    Ts(run) = Poisson2DWithHeatSource(hs(run));
end

for i = 1:length(hs)-2
    ratios(i) = (Ts(i)-Ts(i+1))/(Ts(i+1) - Ts(i+2));
end

% plot(ratios, 'k-', 'LineWidth', 3)
% grid on
% (Ts(1) - Ts(2))/(Ts(2) - Ts(3))