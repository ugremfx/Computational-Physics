L = 5;
N = 10000;

h = L/N;

f = 100;

boundaryL = 40;
boundaryR = 400;

A = sparse(N+1, N+1);
b = zeros(N+1, 1);

for i = 2:N
    A(i-1, i-1) =  1;
    A(i-1, i)   = -2;
    A(i-1, i+1) =  1;
    
    b(i-1) = -h^2*f;  % The equation is -Laplacian(T) = f
end

A(N, 1) = 1;      b(N)   = boundaryL;
A(N+1, N+1) = 1;  b(N+1) = boundaryR;

T = A\b;

x = (0:h:L)';

plot(x, T, 'k-', 'LineWidth', 3, 'MarkerSize', 20)
grid on
figure(gcf)