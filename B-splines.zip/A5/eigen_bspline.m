% Assignment 5: Eigenvalue problems with B-splines


% Construct the knot sequence

%r = logspace(-6,2,20000); % Bohr radiuses exponential distribution
r = linspace(1e-6,50,10000); % Bohr radiuses

Z = 1; 
%Z = 92; % For uranium nucleus

R0 = 1.5; % [Bohr radiuses] The radius of sphere for the case with spherical charge distribution
%AD = 238; % Mass number of Urnaium nucleus
%R0= 1.2*(10^-15)*AD^(1/3)/(5.2917721090380*10^-11); % Radius of the potential well

kord = 4; % The order of splines. For cubic splines kord = 4

% Knot points
tknot = repmat(r(1),1,kord);
kk = kord;
kh = 5;
while kh <= length(r)
    kk = kk+1;
    tknot(kk) = r(kh);
    kh = kh + 200; % Adjust here the step for taking knot points
end
tknot = [tknot repmat(r(end),1,kord)];

% tknot values must be included in r vector!
if ~issorted(tknot)
    fprintf('Knot points are not sorted!\n')
return
end


%% Generate the splines and their derivatives
[Bavx,dBavx,dB2avx] = bsplgen(r,tknot,kord); % Generate the B-splines on the given grid and knot points
r = r'; % Transpose in order to work with column vectors
tknot = tknot';

N = length(tknot); % Number of knot points


%% Construct matrices H and B
lval = 0; % Azimuthal quantum number (angular momentum)

% Initializations
H = zeros(N-kord,N-kord); % Initialization with a aquare zero matrix of dimensions N-kord
B = H;
H2 = H;

Hfunc_to_int2 = zeros(length(r),1); % Initialization of the integrand of equation 9 (Assignment 5) for the case of uniform charge distribution in a sphere of radius R0.
for ii = 1:size(H,1)
    for jj = 1:size(H,2)
        % Point charge Coulomb potential
        int_interv = (r >= tknot(max(ii,jj))) & (r <= tknot(min(ii,jj)+kord)); % Logical array corresponding to the integration interval in r, where splines are non-zero
        Hfunc_to_int = Bavx(int_interv,jj).*(-1/2*dB2avx(int_interv,ii) + 1/2*lval*(lval+1)*1./r(int_interv).^2.*Bavx(int_interv,ii) - Z./r(int_interv).*Bavx(int_interv,ii));
        % Integrate the integrand
        H(ii,jj) = Gauss_int(r(int_interv), Hfunc_to_int,64);
        B(ii,jj) = Gauss_int(r(int_interv),Bavx(int_interv,jj).*Bavx(int_interv,ii),64);
        
        % Spherical Charge Distribution
        for kk = 1:length(r)
            if r(kk) < R0
                Hfunc_to_int2(kk) = Bavx(kk,jj).*(-1/2*dB2avx(kk,ii) + 1/2*lval*(lval+1)*1./r(kk)^2.*Bavx(kk,ii) - Z/(2*R0)*(3 - (r(kk)/R0)^2).*Bavx(kk,ii));
            else
                Hfunc_to_int2(kk) = Bavx(kk,jj).*(-1/2*dB2avx(kk,ii) + 1/2*lval*(lval+1)*1./r(kk)^2.*Bavx(kk,ii) - Z./r(kk).*Bavx(kk,ii));
            end
        end
        % Integrate for the second case (spherical charge distr.)
        H2(ii,jj) = Gauss_int(r(int_interv),Hfunc_to_int2(int_interv),64);
        
    end
end

% Modify H matrix with boundary conditions ??? Is it correct the way we do
% it?
H(1,:) = 0; % Make the first row of matrix H equal to 0
H(1,1) = 0; % The function at the left boundary is 0
H(end,:) = 0;
H(end,end) = 0; % The function at the right boundary is 0 if the domain is large enough

H2(1,:) = 0; % Matrix H2 corresponds to the spherical charge distribution
H2(1,1) = 0; % The function at the left boundary is 0
H2(end,:) = 0;
H2(end,end) = 0; % The function at the right boundary is 0 if the domain is large enough


%% Solve the Generalized Eigenvalue problem
[c,E] = eig(H,B); % Each column in matrix c is an eigenvector. Each row corresponds to a B-spline coeffcient (see eq. 4)
[c2,E2] = eig(H2,B);

Ener = diag(E); % Vectors obtained by extracting the diagonal of matrix E
Ener2 = diag(E2);


%% Sort results to obtain the ground state
[Ener_ord, Ind_ener] = sort(Ener,'ascend');
c_ord = c(:,Ind_ener);

[Ener_ord2, Ind_ener2] = sort(Ener2,'ascend');
c_ord2 = c2(:,Ind_ener2);


%% Calculate P_nl
Pnl = zeros(length(r),N-kord); % Initialize P_nl
for jj = 1:(N-kord)
    for ii = 1:(N-kord)
        Pnl(:,jj) = Pnl(:,jj) + c_ord(ii,jj)*Bavx(:,ii);
    end
end

Pnl2 = zeros(length(r),N-kord); % For the spherical charge
for jj = 1:(N-kord)
    for ii = 1:(N-kord)
        Pnl2(:,jj) = Pnl2(:,jj) + c_ord2(ii,jj)*Bavx(:,ii);
    end
end



%% Plots
Noptr = 4; % Number of points to remove at the origin
fqn_n = 1; % Fundamental quantum number used for plots below

figure
plot(r(Noptr:end),-Pnl(Noptr:end,fqn_n)./r(Noptr:end),'Linewidth',1.2)
hold on
plot(r(Noptr:end),Pnl(Noptr:end,fqn_n+1)./r(Noptr:end),'-','Linewidth',1.2)

% Spherical charge
plot(r(Noptr:end),Pnl2(Noptr:end,fqn_n)./r(Noptr:end),'--','Linewidth',1.2)
plot(r(Noptr:end),-Pnl2(Noptr:end,fqn_n+1)./r(Noptr:end),'--','Linewidth',1.2)

xlabel('r [Bohr radiuses]')
ylabel('Radial wavefunction R_{nl} = P_{nl}/r')
legend(sprintf('R_{%d%d} point charge',fqn_n,lval),sprintf('R_{%d%d} point charge',fqn_n+1,lval),sprintf('R_{%d%d} spherical charge with R_0 = %3.3e',fqn_n,lval, R0), sprintf('R_{%d%d} spherical charge with R_0 = %3.3e',fqn_n+1,lval, R0))
grid on
xlim([0,10])
ylim([-1,5])


%{
%% Plots
Noptr = 400*9; % Number of points to remove at the origin
fqn_n = 2; % Fundamental quantum number used for plots below

figure
semilogx(r(Noptr:end),-Pnl(Noptr:end,fqn_n)./r(Noptr:end),'Linewidth',1.2)
hold on
semilogx(r(Noptr:end),-Pnl(Noptr:end,fqn_n+1)./r(Noptr:end),'-','Linewidth',1.2)

% Spherical charge
plot(r(Noptr:end),-Pnl2(Noptr:end,fqn_n)./r(Noptr:end),'--','Linewidth',1.2)
plot(r(Noptr:end),-Pnl2(Noptr:end,fqn_n+1)./r(Noptr:end),'--','Linewidth',1.2)

xline(R0,'--',{'R_0'})
xlabel('r [Bohr radiuses]')
ylabel('Radial wavefunction R_{nl} = P_{nl}/r')
legend(sprintf('R_{%d%d} point charge',fqn_n,lval),sprintf('R_{%d%d} point charge',fqn_n+1,lval),sprintf('R_{%d%d} spherical charge with R_0 = %3.3e',fqn_n,lval, R0), sprintf('R_{%d%d} spherical charge with R_0 = %3.3e',fqn_n+1,lval, R0))
grid on
%xlim([0,0.5])
%ylim([-55,180])
%}

