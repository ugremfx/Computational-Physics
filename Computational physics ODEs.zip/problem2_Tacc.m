


h = 0.001;
T = 20;
R0 = [1.2;0;0;-1];
TOL = 0.25;


M_AD4_h = AD4(h, T, R0);
M_AD4_h2 = AD4(h/2, T, R0);

T_acc_AD4 = compTacc(M_AD4_h, M_AD4_h2, TOL, h);

M_RK3_h = RK3(h, T, R0);
M_RK3_h2 = RK3(h/2, T, R0);

T_acc_RK3 = compTacc(M_RK3_h, M_RK3_h2, TOL, h);

M_Euler_h = Euler(h, T, R0);
M_Euler_h2 = Euler(h/2, T, R0);

T_acc_Euler = compTacc(M_Euler_h, M_Euler_h2, TOL, h);



T_accs = table(T_acc_AD4, T_acc_RK3, T_acc_Euler)

writetable(T_accs, 'Problem2_table_Taccs.txt','WriteRowNames',true);


[T_acc_max, method_max] = max([T_acc_AD4 T_acc_RK3 T_acc_Euler]);

if method_max == 1
    M_max = AD4(h, T_acc_max, R0);
    method = 'AD4';
elseif method_max == 2
    M_max = RK3(h, T_acc_max, R0);
    method = 'RK3';
else
    M_max = Euler(h, T_acc_max, R0);
    method = 'Euler';
end

comet(M_max(1,1:ceil(T_acc_max/h)),M_max(2,1:ceil(T_acc_max/h)))


t = linspace(0,T_acc_max,ceil(T_acc_max/h));
plot(t,M_max(1,1:ceil(T_acc_max/h)),t,M_max(2,1:ceil(T_acc_max/h)))   %plot of r(t)
title(['trajectory (x(t), y(t)) upto t = Tacc for the most accurate method: ' method])
legend('x(t)','y(t)')
xlabel('t')
savefig('problem2_trajectory_mostacc.fig')
saveas(gcf, 'problem2_trajectory_mostacc.png')

function T_acc = compTacc(M_h, M_h2, TOL, h)
    
    tol = vecnorm(M_h - M_h2(:,1:2:2*length(M_h)));
    N_acc = find(tol > TOL, 1, 'first');
    T_acc = N_acc * h;

end




function M = AD4(h, T, R0)
    
    N = ceil(T/h);
    M = zeros(4,N+1);
    M(:,1) = R0;
                
        %%%%Rk + AD4%%%%
        %Compute first three time steps via RK4.
    R = R0;
    for i = 1:3
        k1 = dRdt(R);
        k2 = dRdt(R+h*k1);
        k3 = dRdt(R+0.25*h*k1+0.25*h*k2);
        R = R + (h/6)*(k1+k2+4*k3);
        M(:,i+1) = R;
    end
    R1 = M(:,2); R2 = M(:,3); R3 = M(:,4);
    
    for i = 4:N
        R = R + (h/24)*(55*dRdt(R)-59*dRdt(R2)+37*dRdt(R1)-9*dRdt(R0));
        M(:,i+1) = R;
        R0 = R1; R1 = R2; R2 = R3; R3 = R;   %re-assign for next loop.
    end
                
                
end

function M = RK3(h, T, R0)
    N = ceil(T/h);
    M = zeros(4,N+1);
    M(:,1) = R0;
    R = R0;
    for i = 1:N
        k1 = dRdt(R);
        k2 = dRdt(R+h*k1);
        k3 = dRdt(R+0.25*h*k1+0.25*h*k2);
        R = R + (h/6)*(k1+k2+4*k3);
        M(:,i+1) = R;
    end
    
end

function M = Euler(h, T, R0)
    N = ceil(T/h);
    M = zeros(4,N+1);
    M(:,1) = R0;
    R = R0;
    for i = 1:N
        R = R + h*dRdt(R);
        M(:,i+1) = R;
    end
end


function f = dRdt(R)
    mu = 1/82.45;
    r = R(1:2);
    mu = 1/82.45;
    r0 = [-mu;0];
    r1 = [1-mu;0];
    f = zeros(4,1);
    f(1) = R(3); f(2) = R(4);   %r' = s;
    norm0 = (norm(r-r0,2))^3;   norm1 = (norm(r-r1,2))^3;
    f(3) = -(1-mu)*(r(1)-r0(1))/norm0 - mu*(r(1)-r1(1))/norm1+r(1)+2*R(4);
    f(4) = -(1-mu)*(r(2)-r0(2))/norm0 - mu*(r(2)-r1(2))/norm1+r(2)-2*R(3);
end