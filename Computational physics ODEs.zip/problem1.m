%%Problem 1%%
function MNT = problem1(N)
%data%
m0 = [1;0;0];
alpha = 0.1;
T = 40;
t = linspace(0,T,N+1);  %time vector.
M = zeros(3,N+1);   %solution vector.
M(:,1) = m0;    %set initial condition.
h = t(2)-t(1);  %time step size.
a = 0.5*[1;1;sqrt(2)];

m = m0;
for i = 1:N
    k1 = dmdt(m);
    k2 = dmdt(m+h*k1);
    k3 = dmdt(m+0.25*h*k1+0.25*h*k2);
    m = m + (h/6)*(k1+k2+4*k3);
    M(:,i+1) = m;
end

%plots
m1 = M(1,:);
m2 = M(2,:);
m3 = M(3,:);
figure();
plot(t,m1,t,m2,t,m3)
xlabel('t')
ylabeltext=(['magnetization vector for N = ',num2str(N)]);
ylabel(ylabeltext)
legend('m1','m2','m3')
clf
Mnorm = M;
for i = 1:N+1
    Mnorm(:,i) = M(:,i) / norm(M(:,i),2);
end

figure();
p2 = plot3(Mnorm(1,:),Mnorm(2,:),Mnorm(3,:),'.k','Markersize',10);
hold on
plot3(a(1),a(2),a(3),'.r','Markersize',10)
axis equal
titletext=(['normalized magnetization vector for N = ',num2str(N)]);
title(titletext)
legend('m/|m|','a')

MNT = M(:,end);

%function for f(t,m)$

function f = dmdt(m)
    a = 0.5*[1;1;sqrt(2)];
    alpha = 0.1;
    f = cross(a,m)+alpha*cross(a,cross(a,m));
end

%function for R(h*lambda).
%find eigenvalues of A.
A = zeros(3,3);
A(:,1) = dmdt([1;0;0]);
A(:,2) = dmdt([0;1;0]);
A(:,3) = dmdt([0;0;1]);
E = eigs(A);
lambda = E(1); %try first eigenvalue.
%Estimate stability limit.
h = 0.1;
while (abs(1+(h*lambda)+(4/3)*(h*lambda)^2+(2/3)*(h*lambda)^3)<=1)%for 3rd-order RK defined in assignment
    h = h+0.1;
end
%final value of h is stability limit (found to be 1.3).

clf
%figure()
%Create stability region contour plot.
[X,Y] = meshgrid(-1:0.001:1,-1:0.001:1);
Mu = X+i*Y;
R = 1 + Mu + (4/3)*Mu.^2 + (2/3)*Mu.^3;% + (1/24)*Mu.^4;
Rhat = abs(R);
contour(X,Y,Rhat,'ShowText','on')%,[0.25, 0.5, 0.75, 1],'ShowText','on');
xlabel("Re(z)")
ylabel("Im(z)")
title("Stability region for z=n*l")






































end
