
lambda = -0.1 + 1i;
stabh=@(h) stab(h*lambda);

h = 0.01;
while (stabh(h)<=1)%for 3rd-order RK defined in assignment
    h = h+0.01;
end

h
stabh(h)
%final value of h is stability limit (found to be 1.3).

%Create stability region contour plot.
[X,Y] = meshgrid(-3:0.01:0.5,-3:0.01:3);
Mu = complex(X,Y);
Rhat = stab(Mu);
contour(X,Y,Rhat,[0.25, 0.5, 0.75, 1],'ShowText','on');
hold on
h = linspace(0, 4, 50);
hl = lambda * h;
scatter(real(hl), imag(hl), 8, h, '+')
c = colorbar;
c.Label.String = "h";
legend("Contour of stability region RK3","h*lambda for current problem")
hold off
xlabel("Re(z)")
ylabel("Im(z)")
title("Stability region for z=n*l")
saveas(gcf, "problem1_stabilityregion.png")



function out = stab(z)
    out = abs(1 + z + (1/2)*z.^2 + (1/6)*z.^3);
end