tspan = [0 1000];
X0 = [1;0;0];
OPTIONS = odeset('RelTol',1e-5,'AbsTol',1e-8); %relative tolerance 10^(-3).
[t,X] = ode23s(@dXdt,tspan,X0,OPTIONS);

% %plots of x1,x2, and x3.
% loglog(t,X(:,1),t,X(:,2),t,X(:,3))
% legend('x1(t)','x2(t)','x3(t)')
% xlabel('t')

%plot of step size as function of t.
figure()
steps = t(2:end)-t(1:end-1);
numsteps_first_rel_tol = length(steps);
plot(t(1:end-1),steps)
xlabel('t')
title("RelTol = 1e-5, AbsTol = 1e-8")
ylabel('time step sizes')
max_tstep = max(steps);
min_tstep = min(steps);
saveas(gcf,"problem3_ode23s_e5.png")
clf
OPTIONS = odeset('RelTol',1e-11,'AbsTol',1e-14); %relative tolerance 10^(-3).
[t,X] = ode23s(@dXdt,tspan,X0,OPTIONS);
figure()
steps = t(2:end)-t(1:end-1);
numsteps_second_rel_tol = length(steps);
plot(t(1:end-1),steps)
xlabel('t')
title("RelTol = 1e-11, AbsTol = 1e-14")
ylabel('time step sizes')
max_tstep = max(steps);
min_tstep = min(steps);
saveas(gcf,"problem3_ode23s_e11.png")

function f = dXdt(t,X)
    f = zeros(3,1);
    r1 = 0.04; r2 = 1e4; r3 = 3e7;
    f(1) = -r1*X(1) + r2*X(2)*X(3);
    f(2) = r1*X(1) - r2*X(2)*X(3) -r3*X(2)^2;
    f(3) = r3*X(2)^2;
end