tspan = [0 5];
R0 = [1.2;0;0;-1];
opts = odeset('RelTol',1e-4);
[t,R] = ode23(@dRdt,tspan,R0, opts);

%animation
comet(R(:,1),R(:,2))

%
plot(t,R(:,1),t,R(:,2))   %plot of r(t)
title('trajectory (x(t), y(t)) upto t = Tacc for ode23')
legend('x(t)','y(t)')
xlabel('t')
savefig('problem2_trajectory_ode23.fig')
saveas(gcf, 'problem2_trajectory_ode23.png')

%analyze time steps
figure()
steps = t(2:end)-t(1:end-1);
numsteps = length(steps);
plot(t(1:end-1),steps)
title('size of the time steps as a function of time')
ylabel('time step sizes')
xlabel('t')
max_tstep = max(steps);
min_tstep = min(steps);
savefig('problem2_timestepsizes.fig')
saveas(gcf, 'problem2_timestepsizes.png')

tsteps_AD4 = 0.001;
tstep_comparison = table(tsteps_AD4, min_tstep, max_tstep)

writetable(tstep_comparison, 'Problem2_table_tSteps.txt','WriteRowNames',true);

function f = dRdt(t,R)
    r = R(1:2);
    mu = 1/82.45;
    r0 = [-mu;0];
    r1 = [1-mu;0];
    f = zeros(4,1);
    f(1) = R(3); f(2) = R(4);   %r' = s;
    norm0 = (norm(r-r0,2))^3;   norm1 = (norm(r-r1,2))^3;
    f(3) = -(1-mu)*(r(1)-r0(1))/norm0 - mu*(r(1)-r1(1))/norm1+r(1)+2*R(4);
    f(4) = -(1-mu)*(r(2)-r0(2))/norm0 - mu*(r(2)-r1(2))/norm1+r(2)-2*R(3);
end