%%Problem 2%%
function [M_AD4,M_RK,M_EE] = problem2(Num)
%data%
mu = 1/82.45;
T = 7;
t = linspace(0,T,Num+1);  %time vector.
h = t(2)-t(1);  %time step size.
M = zeros(4,Num+1);   %solution vector.
R0 = [1.2;0;0;-1];  %initial condition.
M(:,1) = R0;    %set initial condition.


%%%%Rk + AD4%%%%
%Compute first three time steps via RK4.
R = R0;
for i = 1:3
    k1 = dRdt(R);
    k2 = dRdt(R+h*k1);
    k3 = dRdt(R+0.25*h*k1+0.25*h*k2);
    R = R + (h/6)*(k1+k2+4*k3);
    M(:,i+1) = R;
end

%Compute remaining time steps with Adams-Bashforth.
R1 = M(:,2); R2 = M(:,3); R3 = M(:,4);
for i = 4:Num
    R = R + (h/24)*(55*dRdt(R)-59*dRdt(R2)+37*dRdt(R1)-9*dRdt(R0));
    M(:,i+1) = R;
    R0 = R1; R1 = R2; R2 = R3; R3 = R;   %re-assign for next loop.
end

M_AD4 = M;

%%%%Rk all the way%%%%
M = zeros(4,Num+1);   %solution vector.
R0 = [1.2;0;0;-1];  %initial condition.
R = R0;
M(:,1) = R0;    %set initial condition.
for i = 1:Num
    k1 = dRdt(R);
    k2 = dRdt(R+h*k1);
    k3 = dRdt(R+0.25*h*k1+0.25*h*k2);
    R = R + (h/6)*(k1+k2+4*k3);
    M(:,i+1) = R;
end

M_RK = M;

%%%%Explicit Euler%%%%
M = zeros(4,Num+1);   %solution vector.
R0 = [1.2;0;0;-1];  %initial condition.
R = R0;
M(:,1) = R0;    %set initial condition.
for i = 1:Num
    R = R + h*dRdt(R);
    M(:,i+1) = R;
end

M_EE = M;

%plots (comment off to suppress plot when doing Tacc computations.

M = M_AD4;
figure()
plot(t,M(1,:),t,M(2,:))   %plot of r(t)
legend('x(t)','y(t)')
title('position coordinates r(t) = (x(t), y(t)) as a function of t for t ∈ [0, 7]')
xlabel('t')
savefig('problem2_trajectory_r_AD4.fig')
saveas(gcf, 'problem2_trajectory_r_AD4.png')
figure()
plot(t,M(3,:),t,M(4,:))   %plot of r'(t)
legend('vx(t)','vy(t)')
title('velocities r(t) = (x(t), y(t)) as a function of t for t ∈ [0, 7]')
xlabel('t')
savefig('problem2_trajectory_v_AD4.fig')
saveas(gcf, 'problem2_trajectory_v_AD4.png')

figure()
plot(M(1,:),M(2,:),'.k','Markersize',10)    %trajectory r(t)
title('trajectory of the satellite in the (x, y)-plane')
hold on
plot(-mu,0,'.r','Markersize',20)            %earth location
hold on
plot(1-mu,0,'.b','Markersize',20)           %moon location
legend('trajectory', 'earth', 'moon')
axis equal
savefig('problem2_trajectory_xy.fig')
saveas(gcf, 'problem2_trajectory_xy.png')


MNT = M(:,end);


%function for f(t,R)$

function f = dRdt(R)
    r = R(1:2);
    mu = 1/82.45;
    r0 = [-mu;0];
    r1 = [1-mu;0];
    f = zeros(4,1);
    f(1) = R(3); f(2) = R(4);   %r' = s;
    norm0 = (norm(r-r0,2))^3;   norm1 = (norm(r-r1,2))^3;
    f(3) = -(1-mu)*(r(1)-r0(1))/norm0 - mu*(r(1)-r1(1))/norm1+r(1)+2*R(4);
    f(4) = -(1-mu)*(r(2)-r0(2))/norm0 - mu*(r(2)-r1(2))/norm1+r(2)-2*R(3);
end

end












