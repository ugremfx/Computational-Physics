run problem1(40)    %create stable plot corresponding to h = 1.

run problem1(10)    %create stable plot corresponding to h = 4.