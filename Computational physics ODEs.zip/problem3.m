%%Problem 3%%
function M = problem3(Num)
%data%
T = 1;
t = linspace(0,T,Num+1);  %time vector.
h = t(2)-t(1);  %time step size.
M = zeros(3,Num+1);   %solution vector.
X0 = [1;0;0];  %initial condition.
M(:,1) = X0;    %set initial condition.
X = X0;
%%%%Rk all the way%%%%
for i = 1:Num
    k1 = dXdt(X);
    k2 = dXdt(X+h*k1);
    k3 = dXdt(X+0.25*h*k1+0.25*h*k2);
    X = X + (h/6)*(k1+k2+4*k3);
    M(:,i+1) = X;
end

%plots (comment off to suppress plot when doing Tacc computations).

figure()
loglog(t,M(1,:),t,M(2,:),t,M(3,:))   %plot of r(t)
legend('x1(t)','x2(t)','x3(t)')
title("Solutions in a loglog-diagram using the smallest step size (N = 2000)")
xlabel('t')
saveas(gcf, "problem3sol.png")

%function for f(t,X)$

function f = dXdt(X)
    f = zeros(3,1);
    r1 = 0.04; r2 = 1e4; r3 = 3e7;
    f(1) = -r1*X(1) + r2*X(2)*X(3);
    f(2) = r1*X(1) - r2*X(2)*X(3) -r3*X(2)^2;
    f(3) = r3*X(2)^2;
end

end












