N1 = problem1(20);
N2 = problem1(40);
N3 = problem1(80);
N4 = problem1(160);
N5 = problem1(320);
N6 = problem1(640);
N7 = problem1(1280);
N8 = problem1(1560);

h = 40./[20,40,80,160,320,640,1280,1560];
V = [N1,N2,N3,N4,N5,N6,N7,N8];

errs = zeros(1,7);
for i = 1:7
    err(i) = norm(V(:,i+1)-V(:,i));
end

figure()
loglog(h(1:7),err,'.-k','Markersize',20)
xlabel('h (step size)')
ylabel('Error Approximation')

logh = log10(h(1:7));
logerr = log10(err);

%Linear regression to find order p.
p = polyfit(logh,logerr,1);